# Resume Screener

A simple, friendly resume screener that highlights missing skills, a fit score, and a readable summary. No setup needed — just open index.html.

## Features
- Paste Job Description and Resume text
- Detects skills and highlights what’s missing
- Fit score with visual progress bar
- Plain-language candidate summary
- One-click PDF report download

## How to run
- Windows: double-click `index.html` to open in your browser.
- Or serve locally (optional):
  - PowerShell: `Start-Process msedge index.html` (or open with your default browser)

## Notes
- This version uses React and Tailwind via CDN for simplicity and zero setup.
- You can later migrate to a framework (e.g., Next.js) if you want routing, SSR, or a richer build process.
