# WARP.md

This file provides guidance to WARP (warp.dev) when working with code in this repository.

Repository overview
- There are two UIs in this repo:
  - A fully working, zero-deps static app at the repository root (index.html) using React, Tailwind via CDN, and inline JSX compiled by Babel in the browser.
  - A Vite + React + TypeScript project scaffold in app/ with lint/build/dev scripts but no src/ implementation yet.

Common commands

Static app (root)
- Open in a browser (Windows PowerShell):
  - Start-Process msedge index.html
- Or double-click index.html in your file explorer.

Vite app (app/)
Run these from the app directory.
- Install dependencies:
  - npm install
- Start dev server (Vite):
  - npm run dev
- Lint:
  - npm run lint
- Build (type-check + bundle):
  - npm run build
- Preview production build:
  - npm run preview

Testing
- No test runner is configured in this repository at present. Running a single test is not applicable until tests are added.

Architecture and code structure

Root single-file app (index.html)
- Tech: React via UMD, ReactDOM via UMD, Tailwind via CDN, in-browser Babel.
- High-level flow:
  - Input state: job description (JD) text, resume text, candidate name, years of experience.
  - Skill detection: tokenize() lowercases and splits free text; extractSkillsFromJD() intersects tokens with a small defaultSkills vocabulary.
  - Scoring: computeScore() combines JD/resume skill coverage (80%) and experience factor (20%) to compute an integer score 0–100. Coverage and missing skills are derived from simple set logic.
  - Summary: Constructs a short, human-readable summary based on strengths (matched skills), key gaps (missing skills), and the score bucket.
  - UI composition: Inline React components (Badge, Section, ActionButton) organize the layout. Tailwind classes style sections and badges. A progress bar visualizes the score.
  - Export: downloadPDF() uses jsPDF to generate a printable report including candidate, score, summary, and missing skills.
- What to know quickly:
  - All logic and UI live in a single HTML file; there is no bundler or build step for the root app. This makes it fast to iterate but means no module boundaries.
  - If you change defaultSkills or tokenization rules, you affect detection, coverage, score, and the summary simultaneously.

Vite scaffold (app/)
- Configured pieces:
  - Vite with @vitejs/plugin-react (vite.config.ts)
  - TypeScript project references (tsconfig.json → tsconfig.app.json, tsconfig.node.json) with strict, noEmit bundler settings.
  - ESLint (eslint.config.js) with @eslint/js, typescript-eslint, react-hooks, and react-refresh integrations.
- Not present:
  - src/ implementation files are not yet added.
  - Test tooling (e.g., Vitest/Jest) is not configured.
- Implications:
  - npm run dev/build/lint/preview work at the tooling level, but there’s no app code until src/ is added.

Docs and rules surfaced
- README.md (root): Emphasizes the static, no-setup workflow (open index.html), features (skill highlighting, fit score, summary, PDF export).
- No CLAUDE.md, Cursor rules, Copilot instructions, or other agent rule files were found.

Notes for future changes
- If you move functionality from the root app into app/, remember that the TypeScript config enforces strictness and bundler-style module resolution; align imports and types accordingly.
- If/when tests are introduced, prefer documenting how to run a single test file and test name pattern here (e.g., Vitest’s -t/--testNamePattern).